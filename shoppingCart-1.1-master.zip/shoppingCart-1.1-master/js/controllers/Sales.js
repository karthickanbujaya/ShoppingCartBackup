define(['./module'], function (controllers) {

	'use strict';
	
    return controllers.controller('SalesCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Sales.js File is loading....");
		}


	]);
});