define(['./module'], function (controllers) {
   
   'use strict';

    return controllers.controller('DataCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Data.js File is loading....");
		}


	]);
});