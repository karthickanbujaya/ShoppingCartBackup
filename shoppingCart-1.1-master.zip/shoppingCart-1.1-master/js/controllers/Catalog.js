 define(['./module'], function(controllers) {

	 'use strict';

    return controllers.controller('CatalogCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Catalog.js File is loading....");
		}

	]);
	
});

 