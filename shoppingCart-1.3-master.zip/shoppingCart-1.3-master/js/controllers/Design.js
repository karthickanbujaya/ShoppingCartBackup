define(['./module'], function (controllers) {

	'use strict';
	
    return controllers.controller('DesignCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Design.js File is loading....");
		}


	]);
});