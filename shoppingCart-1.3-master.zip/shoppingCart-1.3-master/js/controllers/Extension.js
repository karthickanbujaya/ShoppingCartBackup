define(['./module'], function (controllers) {
	
	'use strict';

    return controllers.controller('ExtensionCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Extension.js File is loading....");
		}


	]);
});