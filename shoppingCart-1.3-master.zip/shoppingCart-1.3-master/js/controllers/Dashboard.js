define(['./module'], function (controllers) {
	
	'use strict';

    return controllers.controller('DashboardCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Dashboard.js File is loading....");
		}


	]);
	
});