It's a improvement in angular+require seed.
I make ui-router into require.js.

See [Angular + Require](http://www.startersquad.com/blog/angular-require/) post on [StarterSquad blog](http://www.startersquad.com/blog/).

Example of Angular + Require usage - shows how to enabled RequireJS for Angular Seed.

See this example [in browser](www.startersquad.com/examples/angularjs-requirejs-2/index-async.html).
