define(['./module'], function (controllers) {

	'use strict';
	
    return controllers.controller('LocalizationCtrl', ['$scope','$state',
        function($scope, uiColumnStates, $state) {

			console.log("Localization.js File is loading....");
		}


	]);
});